gl_list = [6, 3, 9]

# 默认按照升序排序 - 可能会多！
# gl_list.sort()

# 如果需要降序排序，需要执行reverse参数
gl_list.sort(reverse=True)

print(gl_list)
