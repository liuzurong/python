str1 = "hello python"
str2 = '我的外号是"大西瓜"'

print(str2)
print(str1[6])

for char in str2:

    print(char)
