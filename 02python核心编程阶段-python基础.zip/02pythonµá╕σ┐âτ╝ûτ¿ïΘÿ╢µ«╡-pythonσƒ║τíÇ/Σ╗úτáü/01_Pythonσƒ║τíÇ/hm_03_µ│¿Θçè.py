# coding=utf-8
# 这是第一个注释
print("hello hello")

"""
这是一个多行注释

。。。。

。。。。


。。。。
注释结束了
"""
# 这是第二个注释
print("hello world")  # 输出欢迎信息
