print("hello python")
print("你好世界")