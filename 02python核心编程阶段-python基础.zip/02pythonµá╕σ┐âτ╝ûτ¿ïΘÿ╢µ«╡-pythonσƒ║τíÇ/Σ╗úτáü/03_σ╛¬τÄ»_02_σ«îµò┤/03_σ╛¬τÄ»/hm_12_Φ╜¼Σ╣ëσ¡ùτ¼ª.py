# \t 在控制台输出一个 制表符，协助在输出文本时 垂直方向 保持对齐
print("1\t2\t3")
print("10\t20\t30")

# \n 在控制台输出一个 换行符
print("hello\n python")

# \" 可以在控制台输出 "
print("hello\"hello")
