# 全局变量
title = "模块1"


# 函数
def say_hello():
    print("我是 %s" % title)


# 类
class Dog(object):
    pass
