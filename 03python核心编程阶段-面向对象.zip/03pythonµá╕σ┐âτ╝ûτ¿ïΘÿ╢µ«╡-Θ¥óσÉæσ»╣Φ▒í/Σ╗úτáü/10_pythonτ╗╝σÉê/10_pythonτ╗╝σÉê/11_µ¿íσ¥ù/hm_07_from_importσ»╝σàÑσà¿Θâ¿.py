from hm_01_测试模块1 import *
from hm_02_测试模块2 import *

print(title)
say_hello()

wangcai = Dog()
print(wangcai)
