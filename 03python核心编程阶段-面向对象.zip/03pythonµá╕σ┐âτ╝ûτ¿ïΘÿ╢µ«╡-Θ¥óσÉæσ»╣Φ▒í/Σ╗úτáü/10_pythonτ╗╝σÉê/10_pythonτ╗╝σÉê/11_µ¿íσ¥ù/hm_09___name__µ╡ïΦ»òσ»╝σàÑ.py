import hm_09___name__模块

print("-" * 50)
