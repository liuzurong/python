from hm_01_测试模块1 import Dog
from hm_02_测试模块2 import say_hello

say_hello()

wangcai = Dog()
print(wangcai)
