# 1. 打开
file = open("README", "a")

# 2. 写入文件
file.write("123 hello")

# 3. 关闭
file.close()
