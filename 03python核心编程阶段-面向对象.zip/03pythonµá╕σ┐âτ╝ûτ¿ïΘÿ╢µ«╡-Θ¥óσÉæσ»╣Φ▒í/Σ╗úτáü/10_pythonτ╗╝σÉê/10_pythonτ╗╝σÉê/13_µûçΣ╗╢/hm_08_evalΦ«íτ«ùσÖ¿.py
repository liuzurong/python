input_str = input("请输入算术题：")

print(eval(input_str))
